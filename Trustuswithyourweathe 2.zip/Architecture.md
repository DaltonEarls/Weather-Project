i used a lot of UI when it comes to formatting the site,
and making sure you know what ur looking at

the only DRY thing was the tag so i could inst-
-antly color all of the text white without needing to
repeat myself